# Ocreeb12

Watch the build video ↓

[<img src="/Images/001.png">](https://youtu.be/P_oSLBZABGA)

This is a 12 key macro keypad with 2 rotary encoders, custom keycaps and under-glow RGB. 
Ocreeb is running KMK firmware on the Adafruit KB2040.

Order the PCB: [pcbway.com](https://www.pcbway.com/project/shareproject/DIY_Mechanical_Macro_Keypad_Ocreeb_24300065.html)

Build instructions: [instructables.com](https://www.instructables.com/DIY-Mechanical-Macro-Keypad-Ocreeb/)
